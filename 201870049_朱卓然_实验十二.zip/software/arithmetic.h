#ifndef ARITHMETIC_H
#define ARITHMETIC_H


unsigned int __mulsi3(unsigned int, unsigned int);
unsigned int __umodsi3(unsigned int, unsigned int);
unsigned int __udivsi3(unsigned int, unsigned int);


#endif