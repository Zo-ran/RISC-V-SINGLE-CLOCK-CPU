#ifndef FUNC_H
#define FUNC_H

unsigned int fibonacci(unsigned int);
void eval(char *, char *);
unsigned int check(const char *);
void handle_time(char *);

#endif